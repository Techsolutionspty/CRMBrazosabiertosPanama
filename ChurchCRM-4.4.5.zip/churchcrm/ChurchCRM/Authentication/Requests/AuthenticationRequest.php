<?php

namespace ChurchCRM\Authentication\Requests {

    class AuthenticationRequest {
        public function __construct()
        {            
        }
    }

}
