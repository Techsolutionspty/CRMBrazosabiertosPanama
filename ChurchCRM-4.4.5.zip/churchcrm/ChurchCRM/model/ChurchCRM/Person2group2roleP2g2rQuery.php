<?php

namespace ChurchCRM;

use ChurchCRM\Base\Person2group2roleP2g2rQuery as BasePerson2group2roleP2g2rQuery;

/**
 * Skeleton subclass for performing query and update operations on the 'person2group2role_p2g2r' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 */
class Person2group2roleP2g2rQuery extends BasePerson2group2roleP2g2rQuery
{
}
