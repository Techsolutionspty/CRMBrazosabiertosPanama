<?php

namespace ChurchCRM\dto;

abstract class KioskAssignmentTypes
{
  const EVENTATTENDANCEKIOSK = 1;
  const SELFREGISTRATIONKIOSK = 2;
  const SELFCHECKINKIOSK = 3;
  const GENERALATTENDANCEKIOSK = 4;
}

?>