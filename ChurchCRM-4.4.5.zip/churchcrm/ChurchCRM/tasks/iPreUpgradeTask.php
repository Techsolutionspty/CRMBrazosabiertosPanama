<?php

namespace ChurchCRM\Tasks;

interface iPreUpgradeTask extends iTask{

}